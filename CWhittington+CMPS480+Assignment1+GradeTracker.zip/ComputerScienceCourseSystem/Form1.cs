﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace ComputerScienceCourseSystem
{
    public partial class Form1 : Form
    {
        //CWhittington 03-07-21 NEW, 4L initalize the form 
        public Form1()
        {
            InitializeComponent();
        }

        //CWhittington 03-07-21 NEW, 6L create a class student to get and set items
        class Student
        {
            public int StudentID { get; set; }
            public string FirstName { get; set; }
            public string LastName { get; set; }
        }

        //CWhittington 03-07-21 NEW, 7L create a class grade to get and set grade items
        class Grade
        {
            public int GradeID { get; set; }
            public string GradeRec { get; set; }
            public string Assignment { get; set; }
            public int StudentID { get; set; }
        }

        //CWhittington 03-07-21 NEW, 2L initliaze the lists 
        private List<Student> students = new List<Student>();
        private List<Grade> grades = new List<Grade>();
        //CWhittington 03-07-21 NEW, initialize two private variables to be iterrated.
        private int studentID;
        private int gradeID;

        private void nameButton_Click(object sender, EventArgs e)   //CWhittington 03-07-21 NEW, action for click add name
        {
            //CWhittington 03-07-21 NEW, 3L error handling for empty name box 
            if (string.IsNullOrEmpty(nameTextBox.Text.Trim()))
            {
                MessageBox.Show("The name of the student cannot be blank, silly goose!");
            }
            nameTextBox.Text.Trim();   //CWhittington 03-07-21 NEW, trim the text

            //CWhittington 03-07-21 NEW, 1L split the text into two seperate inputs inside an array
            string[] names = nameTextBox.Text.Split(' ');
            //CWhittington 03-07-21 NEW, 1L create an object student 
            Student student = new Student();
            //CWhittington 03-07-21 NEW, 1L iterate StudentID to keep all inputs with one ID only
            student.StudentID = ++studentID;
            //CWhittington 03-07-21 NEW, 1L add first names into the array name
            student.FirstName = names[0];

            //CWhittington 03-07-21 NEW, 4L check to see if there is a last name, if there is, store into the array
            if (names.Count() == 1) {
                student.LastName = string.Empty; }
            else {
                student.LastName = names[names.Count() - 1]; }

            //CWhittington 03-07-21 NEW, 2L store all the inputs into the list and give confirmation message
            students.Add(student);
            outputTextBox.Text = "The student's name was successfully added!";
        }

        private void gradeButton_Click(object sender, EventArgs e)   //CWhittington 03-07-21 NEW, action for clicking add grade
        {
            int gradeRec = 0;   //CWhittington 03-07-21 NEW, create variable gradeRec

            //CWhittington 03-07-21 NEW, 5L Error handling if they try entering a grade without a name attached
            if (string.IsNullOrEmpty(students[students.Count - 1].FirstName) || students.Count == 0)
            {
                MessageBox.Show("You must have a student name entered...");
                return;
            }

            //CWhittington 03-07-21 NEW, 5L error handling if they dont add assignment
            if (string.IsNullOrEmpty(assignTextBox.Text.Trim()))
            {
                MessageBox.Show("Please enter the name of the assignment!");
                return;
            }

            //CWhittington 03-07-21 NEW, 6L error handling if they did not enter a grade as int, if grade is entered it parses as int
            if ( int.TryParse(gradeTextBox.Text, out gradeRec) == false )
            {
                MessageBox.Show("Please enter an integer for the grade, 0-100, goofball!");
                gradeTextBox.Clear();
                return;
            }

            //CWhittington 03-07-21 NEW, 5L error handling if they dont add a grade
            if (string.IsNullOrEmpty(gradeTextBox.Text.Trim()))
            {
                MessageBox.Show("Please enter a grade for the student, coward.");
                return;
            }

            //CWhittington 03-07-21 NEW, 1L create grade object
            Grade grade = new Grade();
            //CWhittington 03-07-21 NEW, 4L increment grade and define the sublists
            grade.GradeID = ++gradeID;
            grade.Assignment = assignTextBox.Text;
            grade.GradeRec = gradeTextBox.Text;
            grade.StudentID = students.Last().StudentID;
            //CWhittington 03-07-21 NEW, 1L add the object into the list
            grades.Add(grade);
            //CWhittington 03-07-21 NEW, 1L give a confirmation message
            outputTextBox.Text = "The student's grade was saved... good luck to both them and you.";
            //CWhittington 03-07-21 NEW, clear all the textboxes
            nameTextBox.Clear();
            assignTextBox.Clear();
            gradeTextBox.Clear();
        }

        private void searchButton_Click(object sender, EventArgs e)   //CWhittington 03-07-21 NEW, action for search click
        {
            //CWhittington 03-07-21 NEW, 1L define string search
            string search = searchTextBox.Text.Trim();

            //CWhittington 03-07-21 NEW, 12L query that checks each item in lists for string search
            var query = grades.Join(
                students,
                grades => grades.GradeID,
                students => students.StudentID,
                (grades, students) => new
                {
                    FirstName = students.FirstName,
                    LastName = students.LastName,
                    Assignment = grades.Assignment,
                    GradeRec = grades.GradeRec,
                }).Where(s => s.FirstName == search || s.LastName == search ||
                 s.Assignment == search || s.GradeRec == search);

            outputTextBox.Clear();   //CWhittington 03-07-21 NEW, clear output textbox

            //CWhittington 03-07-21 NEW, 8L foreach to output what the user search for. Appends to not erase older searches.
            foreach (var result in query)
            {
                outputTextBox.AppendText("Student: " + result.FirstName + " " + result.LastName + 
                    ", received a grade of " + int.Parse(result.GradeRec) + 
                    " on the assignment, " + result.Assignment
                    + Environment.NewLine);
            }
            searchTextBox.Clear();
        }

        private void startButton_Click(object sender, EventArgs e)   //CWhittington 03-07-21 NEW, start button action
        {
            //CWhittington 03-07-21 NEW, 1L define string search
            string search = startTextBox.Text.Trim();

            //CWhittington 03-07-21 NEW, 14L query to search for items in the lists that start with search string
            var query = grades.Join(
                students,
                grades => grades.GradeID,
                students => students.StudentID,
                (grades, students) => new
                {
                    FirstName = students.FirstName,
                    LastName = students.LastName,
                    Assignment = grades.Assignment,
                    GradeRec = grades.GradeRec,
                }).Where(s => s.FirstName.StartsWith(search) == true 
                           || s.LastName.StartsWith(search) == true 
                           || s.Assignment.StartsWith(search) == true
                           || s.GradeRec.StartsWith(search) == true);

            outputTextBox.Clear();   //CWhittington 03-07-21 NEW, clear output textbox

            //CWhittington 03-07-21 NEW, 8L foreach to output what the user searched for.
            foreach (var result in query)
            {
                outputTextBox.AppendText("Student: " + result.FirstName + " " + result.LastName +
                    ", received a grade of " + int.Parse(result.GradeRec) +
                    " on the assignment, " + result.Assignment + "!" 
                    + Environment.NewLine);
            }
            startTextBox.Clear();
        }

        private void endButton_Click(object sender, EventArgs e)   //CWhittington 03-07-21 NEW, end button action
        {
            //CWhittington 03-07-21 NEW, 1L define search string
            string search = endTextBox.Text.Trim();

            //CWhittington 03-07-21 NEW, 14L query to search for items in the lists that start with search string
            var query = grades.Join(
                students,
                grades => grades.GradeID,
                students => students.StudentID,
                (grades, students) => new
                {
                    FirstName = students.FirstName,
                    LastName = students.LastName,
                    Assignment = grades.Assignment,
                    GradeRec = grades.GradeRec,
                }).Where(s => s.FirstName.EndsWith(search) == true
                           || s.LastName.EndsWith(search) == true
                           || s.Assignment.EndsWith(search) == true
                           || s.GradeRec.EndsWith(search) == true);

            outputTextBox.Clear();   //CWhittington 03-07-21 NEW, clear output textbox

            //CWhittington 03-07-21 NEW, 8L foreach to output what the user searched for.
            foreach (var result in query)
            {
                outputTextBox.AppendText("Student: " + result.FirstName + " " + result.LastName +
                    ", received a grade of " + int.Parse(result.GradeRec) +
                    " on the assignment, " + result.Assignment + "!"
                    + Environment.NewLine);
            }
            endTextBox.Clear();
        }
    }
}
